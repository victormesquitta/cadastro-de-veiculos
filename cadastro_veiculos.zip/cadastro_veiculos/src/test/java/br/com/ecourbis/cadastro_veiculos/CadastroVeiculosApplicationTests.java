package br.com.ecourbis.cadastro_veiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroVeiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
