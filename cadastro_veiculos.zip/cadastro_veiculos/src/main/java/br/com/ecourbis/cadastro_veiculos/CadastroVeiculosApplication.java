package br.com.ecourbis.cadastro_veiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroVeiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroVeiculosApplication.class, args);
	}

}
